# -*- coding: utf-8 -*-
"""Prueba una expresión regular contra una web o un archivo HTML, SIN abrir Kodi.

Uso (en tu ordenador, con Python 3):
    python probar_regex.py https://tuweb.com/peliculas/ "<article(.*?)</article>"
    python probar_regex.py pagina.html "<h2[^>]*>(.*?)</h2>"

Muestra cuántas coincidencias hay y las primeras. Úsalo para ajustar cada RE_... de la plantilla.
"""
import re
import sys
import urllib.request

if len(sys.argv) < 3:
    print(__doc__)
    sys.exit(1)

origen, patron = sys.argv[1], sys.argv[2]

if origen.startswith("http"):
    req = urllib.request.Request(origen, headers={"User-Agent": "Mozilla/5.0"})
    html = urllib.request.urlopen(req, timeout=20).read().decode("utf-8", "replace")
else:
    html = open(origen, encoding="utf-8", errors="replace").read()

coincidencias = re.findall(patron, html, re.DOTALL)
print("Coincidencias: %d" % len(coincidencias))
for c in coincidencias[:10]:
    print("-", (c if isinstance(c, str) else c)[:200] if isinstance(c, str) else c)
if not coincidencias:
    print("Ninguna. Revisa el patrón o mira el HTML real de la web (clic derecho > Ver código fuente).")
