# -*- coding: utf-8 -*-
# =====================================================================================
#  PLANTILLA DE SERVIDOR  (películas y series)
#
#  Cómo usarla (resumen; el detalle está en LEEME.txt):
#    1. Copia este archivo y el .json con el MISMO nombre nuevo (ej.: cinexyz.py y cinexyz.json)
#       y cambia "id" y "name" en el .json (el "id" debe ser igual al nombre del archivo).
#    2. Rellena SOLO el bloque "CONFIGURACIÓN" de abajo: la web y las expresiones regulares.
#    3. Importa el par .py + .json (o un .zip con ambos) desde  Servidores · Gestionar >
#       Añadir servidor nuevo.
#
#  El resto del archivo (después de la configuración) normalmente no hay que tocarlo.
# =====================================================================================

import re

from platformcode import config, logger, platformtools
from core.item import Item
from core import httptools, scrapertools, tmdb, servertools


# =====================================================================================
#  CONFIGURACIÓN  (rellena esto)
# =====================================================================================

# Dirección de la web, SIEMPRE acabada en "/"
HOST = 'https://ejemplo.com/'

# Páginas de listado (catálogo). Pon None en la que la web no tenga.
URL_PELICULAS = HOST + 'peliculas/'
URL_SERIES = HOST + 'series/'

# Dirección de búsqueda. {texto} se sustituye por lo que escribe el usuario.
URL_BUSCAR = HOST + '?s={texto}'

# ---- Listado: cómo se reconoce cada ficha (película o serie) en la página ----------
# Cada expresión debe llevar UN grupo entre paréntesis ( ) con lo que se quiere extraer.
RE_FICHA = r'<article(.*?)</article>'               # bloque completo de cada ficha
RE_FICHA_URL = r'<a href="(.*?)"'                   # enlace a la película/serie
RE_FICHA_TITULO = r'<h2[^>]*>(.*?)</h2>'            # título
RE_FICHA_IMAGEN = r'<img[^>]+src="(.*?)"'           # carátula
RE_FICHA_ANIO = r'(?:19|20)\d{2}'                    # año (sin paréntesis: se toma lo que coincida)
RE_FICHA_ES_SERIE = r'/serie/|/series/'             # si la URL de la ficha cumple esto, es una serie

# Enlace a la página siguiente del listado (None si la web no pagina)
RE_SIGUIENTE = r'<a[^>]+class="next[^"]*"[^>]+href="(.*?)"'

# ---- Series: temporadas y episodios (déjalo como está si la web no tiene series) ----
# Temporadas: cada coincidencia da el número de temporada
RE_TEMPORADAS = r'data-season="(\d+)"'
# Episodios: cada coincidencia da (url, número de episodio, título opcional)
RE_EPISODIOS = r'<a href="([^"]+)"[^>]*>\s*(?:<span[^>]*>)?(?:Episodio|Cap[íi]tulo)\s*(\d+)[^<]*'
# Si los episodios de una temporada están en la misma página, este bloque los acota.
# {temporada} se sustituye por el número. Pon None para usar toda la página.
RE_BLOQUE_TEMPORADA = None   # ej.: r'data-season="{temporada}"(.*?)</ul>'

# ---- Idioma por defecto de los enlaces: 'Esp' (castellano), 'Lat' (latino), 'Vose' ----
IDIOMA = 'Esp'

# =====================================================================================
#  FIN DE LA CONFIGURACIÓN
# =====================================================================================


def _descargar(url, post=None):
    """Descarga una página y devuelve su HTML ('' si falla)."""
    try:
        return httptools.downloadpage(url, post=post).data or ''
    except Exception as e:
        logger.error('Error descargando %s: %s' % (url, e))
        return ''


def _limpiar(texto):
    texto = scrapertools.htmlclean(texto or '')
    texto = scrapertools.decodeHtmlentities(texto)
    return texto.strip()


def _abs(url):
    """Convierte una dirección relativa en absoluta."""
    url = (url or '').strip().replace('&amp;', '&')
    if url.startswith('//'): return 'https:' + url
    if url.startswith('/'): return HOST.rstrip('/') + url
    if not url.startswith('http'): return HOST + url
    return url


# ---------------------------------- menús ---------------------------------------------
def mainlist(item):
    logger.info()
    itemlist = []

    if URL_PELICULAS: itemlist.append(item.clone(title='Películas', action='mainlist_pelis', text_color='deepskyblue'))
    if URL_SERIES: itemlist.append(item.clone(title='Series', action='mainlist_series', text_color='hotpink'))

    return itemlist


def mainlist_pelis(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone(title='Buscar película ...', action='search', search_type='movie', text_color='deepskyblue'))
    itemlist.append(item.clone(title='Catálogo', action='list_all', url=URL_PELICULAS, search_type='movie'))

    return itemlist


def mainlist_series(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone(title='Buscar serie ...', action='search', search_type='tvshow', text_color='hotpink'))
    itemlist.append(item.clone(title='Catálogo', action='list_all', url=URL_SERIES, search_type='tvshow'))

    return itemlist


# ---------------------------------- listados ------------------------------------------
def list_all(item):
    logger.info()
    itemlist = []

    data = _descargar(item.url)

    for ficha in scrapertools.find_multiple_matches(data, RE_FICHA):
        url = scrapertools.find_single_match(ficha, RE_FICHA_URL)
        title = _limpiar(scrapertools.find_single_match(ficha, RE_FICHA_TITULO))

        if not url or not title: continue

        url = _abs(url)
        thumb = _abs(scrapertools.find_single_match(ficha, RE_FICHA_IMAGEN)) if RE_FICHA_IMAGEN else ''

        m = re.search(RE_FICHA_ANIO, ficha) if RE_FICHA_ANIO else None
        year = m.group(0) if m else '-'

        es_serie = bool(re.search(RE_FICHA_ES_SERIE, url)) if RE_FICHA_ES_SERIE else False
        if item.search_type == 'tvshow': es_serie = True
        elif item.search_type == 'movie': es_serie = False

        if es_serie:
            itemlist.append(item.clone(action='temporadas', url=url, title=title, thumbnail=thumb,
                                       contentType='tvshow', contentSerieName=title, infoLabels={'year': year}))
        else:
            itemlist.append(item.clone(action='findvideos', url=url, title=title, thumbnail=thumb,
                                       contentType='movie', contentTitle=title, infoLabels={'year': year}))

    tmdb.set_infoLabels(itemlist)  # carátulas y sinopsis desde TMDB

    if itemlist and RE_SIGUIENTE:
        next_page = scrapertools.find_single_match(data, RE_SIGUIENTE)
        if next_page:
            itemlist.append(item.clone(url=_abs(next_page), title='Siguientes ...', action='list_all', text_color='coral'))

    return itemlist


# ---------------------------------- series --------------------------------------------
def temporadas(item):
    logger.info()
    itemlist = []

    data = _descargar(item.url)

    numeros = []
    for t in scrapertools.find_multiple_matches(data, RE_TEMPORADAS):
        if t not in numeros: numeros.append(t)

    if not numeros: numeros = ['1']  # sin temporadas detectadas: se asume una sola

    if len(numeros) == 1:  # una sola temporada: se muestran directamente los episodios
        item.contentType = 'season'
        item.contentSeason = numeros[0]
        return episodios(item)

    for num in numeros:
        itemlist.append(item.clone(action='episodios', title='Temporada ' + num, contentType='season',
                                   contentSeason=num, text_color='tan'))

    tmdb.set_infoLabels(itemlist)

    return itemlist


def episodios(item):
    logger.info()
    itemlist = []

    data = _descargar(item.url)

    season = str(item.contentSeason or '1')

    if RE_BLOQUE_TEMPORADA:
        data = scrapertools.find_single_match(data, RE_BLOQUE_TEMPORADA.replace('{temporada}', season)) or data

    vistos = set()
    for match in scrapertools.find_multiple_matches(data, RE_EPISODIOS):
        url, epi = match[0], match[1]
        if url in vistos: continue
        vistos.add(url)

        titulo = '%sx%s' % (season, str(epi).zfill(2))
        if len(match) > 2 and _limpiar(match[2]): titulo += ' ' + _limpiar(match[2])

        itemlist.append(item.clone(action='findvideos', url=_abs(url), title=titulo, contentType='episode',
                                   contentSeason=season, contentEpisodeNumber=epi))

    tmdb.set_infoLabels(itemlist)

    return itemlist


# ---------------------------------- enlaces de vídeo ----------------------------------
def findvideos(item):
    """Busca en la página los enlaces a los servidores de vídeo que Balandro sabe reproducir
    (iframes y enlaces a Streamwish, Voe, Doodstream, Filemoon, etc.)."""
    logger.info()

    data = _descargar(item.url)
    data = re.sub(r'\n|\r|\t|&nbsp;', ' ', data)

    itemlist = servertools.find_video_items(item, data=data)

    for it in itemlist:
        it.language = IDIOMA

    if not itemlist:
        platformtools.dialog_notification(config.__addon_name, '[COLOR tan][B]Sin enlaces soportados[/B][/COLOR]')
        return

    return itemlist


# ---------------------------------- buscador ------------------------------------------
def search(item, texto):
    logger.info()
    try:
        item.url = URL_BUSCAR.replace('{texto}', texto.replace(' ', '+'))
        return list_all(item)
    except Exception:
        import sys
        for line in sys.exc_info():
            logger.error('%s' % line)
        return []
